import React from 'react'

const PdfViewer = () => {
  return (
    <div>
      pdf viewer
    </div>
  )
}
  
export default PdfViewer
